﻿using FirebaseAdmin;
using FirebaseAdmin.Auth;
using Google.Apis.Auth.OAuth2;
using WebSocketServer.Domain.Entities;
using WebSocketServer.Domain.Interfaces;

namespace WebSocketServer.Infrastructure.Services
{
    public class FirebaseUserService : IFirebaseUserService
    {
        private readonly FirebaseAuth _auth;

        public FirebaseUserService()
        {
            _auth = FirebaseAuth.DefaultInstance;
        }

        public async Task<string> RegisterUserAsync(User user)
        {
            var createdUser = await _auth.CreateUserAsync(new UserRecordArgs()
            {
                Email = user.Email,
                Password = user.Password,
                DisplayName = user.DisplayName,
            });
            return createdUser.Uid;
        }

        public async Task<string> LoginUserAsync(string idToken)
        {
            var token = await _auth.VerifyIdTokenAsync(idToken);
            return token.Uid;
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            var users = new List<User>();
            var pagedEnumerable = _auth.ListUsersAsync(null);

            await foreach (var user in pagedEnumerable)
            {
                users.Add(new User
                {
                    Uid = user.Uid,
                    Email = user.Email,
                    DisplayName = user.DisplayName,
                });
            }

            return users;
        }

        public async Task<User> EditUserAsync(string uid, User updatedUser)
        {
            var userRecord = await _auth.UpdateUserAsync(new UserRecordArgs()
            {
                Uid = uid,
                Email = updatedUser.Email,
                DisplayName = updatedUser.DisplayName,
            });

            return new User
            {
                Uid = userRecord.Uid,
                Email = userRecord.Email,
                DisplayName = userRecord.DisplayName,
            };
        }

        public async Task DeleteUserAsync(string uid)
        {
            await _auth.DeleteUserAsync(uid);
        }
    }
}
