export interface Message {
  id: string;
  text: string;
  userId: string;
  username: string;
  timestamp: Date;
}