export interface Message {
  Id: string;
  Text: string;
  UserId?: string;
  UserName: string;
  Timestamp: Date;
}
