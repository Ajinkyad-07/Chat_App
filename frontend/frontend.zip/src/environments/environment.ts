export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyASld3vFvhV44aXa4eLyE7oLwdmqlZ6T1A",
    authDomain: "chat-app-a0107.firebaseapp.com",
    projectId: "chat-app-a0107",
    storageBucket: "chat-app-a0107.firebasestorage.app",
    messagingSenderId: "925256103291",
    appId: "1:925256103291:web:657977c177d34ae8e2b9de",
    measurementId: "G-ZMP36YX9W4"
  }
};